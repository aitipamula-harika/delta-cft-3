# What is Amazon Simple Email Service? 

Amazon SES is an email platform that provides an easy, cost-effective way for you to send and receive email using your own email addresses and domains. 

For example, you can send marketing emails such as special offers, transactional emails such as order confirmations, and other types of correspondence such as newsletters. When you use Amazon SES to receive mail, you can develop software solutions such as email autoresponders, email unsubscribe systems, and applications that generate customer support tickets from incoming emails. 

## Identity Verification Stack Deployment.
Verify identities in Amazon SES by running the `foundation-iac/DeltaSES/CFTs/id_verification_deployment.yaml` cft using CloudFormation.

## How to run from Management Console

Amazon SES requires that you should verify your emails and domains before you can use them to send and receive emails using the SES or SMTP endpoints. Below are steps to deploy the identity verification CloudFormation template.

### Step 1
Uplaod the following files to an S3 bucket. Create one if you don't have an existing bucket:
`foundation-iac/DeltaSES/CFTs/ses_identity_verification.yaml` and Packages upload the `foundation-iac/DeltaSES/Packages/ses_domain_email_verify.zip`.
### Note!
The S3 bucket that you upload your assets to must be in the same AWS Region as the CloudFormation stack. **Example**, If you are creating your stack in us-east-1 region, then your bucket should also be in that region.

### Step 2
In your AWS Management Console, select CloudFormation, then click `Create stack` and `With new resources (standard)`. 
You can choose `Upload a template file` under `Specify template`, then click `Choose file` to upload `foundation-iac/DeltaSES/CFTs/id_verification_deployment.yaml`. 
Once the template is uploaded, click `Next`.

In `Specify stack details` page, enter `Parameter` values `Domain`, `EmailAddress`, `CfnSESResourcesTemplateURL`, `NestedStackLambdaCodeS3Bucket` and `NestedLambdaCodeS3Key`. The S3 bucket should contain the 3 zip files from Step 1.

### Step 3
Leave the rest options as default and click `Create stack`.