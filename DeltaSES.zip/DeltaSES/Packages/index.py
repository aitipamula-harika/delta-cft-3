from aws_cfn_ses_domain import handle_domain_identity_request, handle_email_identity_request
__all__ = [
    'handle_domain_identity_request',
    'handle_email_identity_request',
]
