# AWS Secrets Manager RDS password rotation
This project is the automated process for rotating password in RDS instances

## Summary
This project is comprised of various folders representing RDS database engines as each process requires different code for rotating passwords. Within each folder is the database client software that is needed by AWS Lambda in order to connect to a database, the AWS Lambda function that will control the creation of the new password and connecting to the database to update the password, and the .zip that contains all of this code so that you can deploy it to your environment.  Please look at the next section for how to use and deploy this code.

## How-To's
### How to use this code in your deployment
This code is designed to be deployed to all accounts and to be run locally by Secrets Manager.  You will add the creation of a lambda with the .zip file contained in the respective db engine folder of this project and the IAM role.  
1. Clone this repository
2. Copy the .zip file from the db engine folder that you need to copy to an S3 bucket in order for the Lambda to use it
3. Deploy the CFT across all accounts via stackset

### Administration - How to update the database client software
The following is a list of files needed in order to the lambda to connect to the respective db engines.  These files will need to updated as the client software updates.  

#### For Oracle
These are the following db client files that are needed: 
<br> (*Please note that 'x' is the version of code and is subject to change)
* cx_Oracle.cpython-37m-x86_64-linux-gnu.so
* libaio.so.1
* libclntsh.so.'x'.1
* libclntshcore.so.'x'.1
* libnnz'x'.so
* libocci.so.'x'.1
* libociei.so
* libocijdbc'x'.so
* liboramysql.so

To get this files, please install the cx_oracle software on to a linux EC2 instance and find the files in /usr/lib64 and /usr/local/lib64 directories. After the files are found/copied, create a .zip file with these new files and the lambda_function.py for deployment.

#### For Postgres
These are the following db client files that are needed: 
* libpq.so
* libpq.so.5
* pg.py
* pgdb.py
* _pg.so (*Note: this file will named with a longer name _pg.cpython... , you will need to rename it to _pg.so)

To get this files, please install the PyGreSQL software from PyPi on to a Red Hat Linux EC2 instance and find the files in /usr/lib64 and /usr/local/lib64 directories. After the files are found/copied, create a .zip file with these new files and the lambda_function.py for deployment.
